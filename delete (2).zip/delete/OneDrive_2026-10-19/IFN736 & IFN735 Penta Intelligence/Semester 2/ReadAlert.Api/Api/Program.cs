using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(o => o.AddDefaultPolicy(p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? ["http://localhost:5173"])
    .AllowAnyHeader()
    .AllowAnyMethod()));

builder.Services.AddHttpClient("OpenLibraryApi", client =>
{
    client.BaseAddress = new Uri("https://openlibrary.org/");
});

var app = builder.Build();
app.UseCors();
app.UseDefaultFiles();
app.UseStaticFiles();

var connectionString = app.Configuration.GetConnectionString("CobbledData")
    ?? throw new InvalidOperationException("ConnectionStrings:CobbledData is required.");

var standalone = app.Environment.IsDevelopment() &&
    string.Equals(app.Configuration["RalStandalone:Enabled"], "true", StringComparison.OrdinalIgnoreCase);

// Health stays unauthenticated; MOD and observability use it to distinguish a down
// service from a valid request which the user cannot perform.
app.MapGet("/api/ral/v01/health", () => Results.Ok(new { service = "RAL", version = "1.0.0", status = "healthy" }));
app.MapGet("/api/ral/v01/readiness", async () =>
{
    try
    {
        await using var db = new SqlConnection(connectionString);
        await db.OpenAsync();
        return Convert.ToInt32(await new SqlCommand("SELECT IIF(OBJECT_ID(N'ral.ral_Authors_CRUD_JSON',N'P') IS NULL,0,1)",
            db).ExecuteScalarAsync()) == 1 ? Results.Ok(new { status = "ready" }) : Results.StatusCode(503);
    }
    catch { return Results.StatusCode(503); }
});

// Shell frames this entry point and posts a signed host context to frontend/app.js.
app.MapGet("/api/ral/{version}/authors", (string version, IWebHostEnvironment env) =>
    version.StartsWith("v01", StringComparison.Ordinal) ? Results.File(Path.Combine(env.WebRootPath, "ral-widget", "index.html"), "text/html; charset=utf-8") : Results.NotFound());

// AUTHOR ENDPOINTS
// GET retrieve authors from local DB
app.MapGet("/api/ral/v01/authors", async (HttpRequest request, string? searchText) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.authors.read")) 
        return Forbidden("ral.authors.read");

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_Authors_CRUD_JSON", "SELECT", new
    {
        SearchText = searchText
    }));
});

// GET retrieve authors from external API; Open Library
app.MapGet("/api/ral/v01/authors/search", async (HttpRequest request, string name, IHttpClientFactory factory) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.authors.read"))
        return Forbidden("ral.authors.read");

    var client = factory.CreateClient("OpenLibraryApi");

    var response = await client.GetAsync(
        $"search/authors.json?q={Uri.EscapeDataString(name)}"
    );

    var json = await response.Content.ReadAsStringAsync();

    return Results.Content(json, "application/json");
});

// POST add new author
app.MapPost("/api/ral/v01/authors", async (HttpRequest request, AuthorCreateInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.authors.write")) 
        return Forbidden("ral.authors.write");

    if (string.IsNullOrWhiteSpace(input.AuthorName)) 
        return Results.BadRequest(new { code = "RAL_AUTHORNAME_REQUIRED" });

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_Authors_CRUD_JSON", "INSERT", new
    {
        AuthorName = input.AuthorName.Trim(),
        AuthorSortName = input.AuthorSortName?.Trim(),
        Biography = input.Biography?.Trim(),
        Country = input.Country?.Trim(),
        WebsiteUrl = input.WebsiteUrl?.Trim(),
        IsVerified = input.IsVerified,
        AuthorComments = input.AuthorComments?.Trim()
    }), 201);
});

// PUT update an existing author
app.MapPut("/api/ral/v01/authors/{authorId}", async (HttpRequest request, string authorId, AuthorUpdateInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.authors.write")) 
        return Forbidden("ral.authors.write");

    if (authorId.Length != 32) 
        return Results.BadRequest(new { code = "RAL_AUTHORNAME_INVALID" });

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_Authors_CRUD_JSON", "UPDATE", new
    {
        AuthorID = authorId,
        AuthorName = input.AuthorName?.Trim(),
        AuthorSortName = input.AuthorSortName?.Trim(),
        Biography = input.Biography?.Trim(),
        Country = input.Country?.Trim(),
        WebsiteUrl = input.WebsiteUrl?.Trim(),
        IsVerified = input.IsVerified,
        AuthorComments = input.AuthorComments?.Trim(),
        IsActive = input.IsActive
    }));
});

// DELETE de-activate an author
app.MapDelete("/api/ral/v01/authors/{authorId}", async (HttpRequest request, string authorId) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.authors.delete")) 
        return Forbidden("ral.authors.delete");

    if (authorId.Length != 32) 
        return Results.BadRequest(new { code = "RAL_INPUT_INVALID" });

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_Authors_CRUD_JSON", "DELETE", new
    {
        AuthorID = authorId
    }));
});

// BOOK ENDPOINTS
// GET /books?searchText=... : list books or filter by title/ISBN.
app.MapGet("/api/ral/v01/books", async (HttpRequest request, string? searchText) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.books.read"))
        return Forbidden("ral.books.read");

    return Json(await ExecuteCrudAsync(
        connectionString,
        scope,
        "ral.ral_Books_CRUD_JSON",
        "SELECT",
        new { SearchText = CleanText(searchText) }));
});

// POST /books : create a book.
app.MapPost("/api/ral/v01/books", async (HttpRequest request, BookRequest input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.books.write"))
        return Forbidden("ral.books.write");

    if (string.IsNullOrWhiteSpace(input.BookTitle))
        return Results.BadRequest(new { code = "RAL_BOOK_TITLE_REQUIRED" });

    var body = CleanBook(input) with
    {
        BookTitle = input.BookTitle.Trim()
    };

    if (!ValidIsbn10(body.ISBN10))
    {
        return Results.BadRequest(new
        {
            code = "RAL_ISBN10_INVALID"
        });
    }

    if (!ValidIsbn13(body.ISBN13))
    {
        return Results.BadRequest(new
        {
            code = "RAL_ISBN13_INVALID"
        });
    }

    if (await DuplicateIsbnExistsAsync(
        connectionString,
        scope,
        body.ISBN10,
        body.ISBN13))
    {
        return Results.Conflict(new
        {
            code = "RAL_ISBN_ALREADY_EXISTS"
        });
    }

    return Json(
        await ExecuteCrudAsync(
            connectionString,
            scope,
            "ral.ral_Books_CRUD_JSON",
            "INSERT",
            body),
        201);
});

// GET /books/{bookId} : retrieve one book.
app.MapGet("/api/ral/v01/books/{bookId}", async (HttpRequest request, string bookId) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.books.read"))
        return Forbidden("ral.books.read");

    if (!ValidId(bookId)) 
        return Results.BadRequest(new { code = "RAL_BOOK_ID_INVALID" });

    return Json(await ExecuteCrudAsync(
        connectionString,
        scope,
        "ral.ral_Books_CRUD_JSON",
        "SELECT",
        new { BookID = bookId }));
});

// PUT /books/{bookId} : update one book.
app.MapPut("/api/ral/v01/books/{bookId}", async (HttpRequest request, string bookId, BookRequest input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.books.write"))
        return Forbidden("ral.books.write");

    if (!ValidId(bookId)) 
        return Results.BadRequest(new { code = "RAL_BOOK_ID_INVALID" });

    if (string.IsNullOrWhiteSpace(input.BookTitle))
        return Results.BadRequest(new { code = "RAL_BOOK_TITLE_REQUIRED" });

    var cleaned = CleanBook(input) with
    {
        BookTitle = input.BookTitle.Trim()
    };

    if (!ValidIsbn10(cleaned.ISBN10))
    {
        return Results.BadRequest(new
        {
            code = "RAL_ISBN10_INVALID"
        });
    }

    if (!ValidIsbn13(cleaned.ISBN13))
    {
        return Results.BadRequest(new
        {
            code = "RAL_ISBN13_INVALID"
        });
    }

    if (await DuplicateIsbnExistsAsync(
        connectionString,
        scope,
        cleaned.ISBN10,
        cleaned.ISBN13,
        bookId))
    {
        return Results.Conflict(new
        {
            code = "RAL_ISBN_ALREADY_EXISTS"
        });
    }

    return Json(await ExecuteCrudAsync(
        connectionString,
        scope,
        "ral.ral_Books_CRUD_JSON",
        "UPDATE",
        new
        {
            BookID = bookId,
            cleaned.ISBN10,
            cleaned.ISBN13,
            cleaned.BookTitle,
            cleaned.Subtitle,
            cleaned.Publisher,
            cleaned.PublishedDate,
            cleaned.Edition,
            cleaned.LanguageCode,
            cleaned.CoverImageUrl,
            cleaned.Description
        }));
});

// GET /external/openlibrary/isbn/{isbn} : look up external book metadata by ISBN.
// This only retrieves information. It does not save anything to Wayne's database.
app.MapGet(
    "/api/ral/v01/external/openlibrary/isbn/{isbn}",
    async (HttpRequest request, string isbn, IHttpClientFactory httpClientFactory) =>
    {
        var scope = await ReadScopeAsync(request, app.Configuration);

        if (scope is null)
            return Results.Unauthorized();

        if (!scope.Has("ral.books.read"))
            return Forbidden("ral.books.read");

        var cleanedIsbn = new string(
            isbn.Where(char.IsLetterOrDigit).ToArray())
            .ToUpperInvariant();

        var validIsbn =
            cleanedIsbn.Length == 13 &&
            cleanedIsbn.All(char.IsDigit)
            ||
            cleanedIsbn.Length == 10 &&
            cleanedIsbn[..9].All(char.IsDigit) &&
            (char.IsDigit(cleanedIsbn[9]) || cleanedIsbn[9] == 'X');

        if (!validIsbn)
        {
            return Results.BadRequest(new
            {
                code = "RAL_EXTERNAL_ISBN_INVALID"
            });
        }

        try
        {
            var client = httpClientFactory.CreateClient("OpenLibraryApi");

            client.DefaultRequestHeaders.UserAgent.ParseAdd(
                "ReadAlert-BookCatalogue/2.0");

            var url = $"isbn/{Uri.EscapeDataString(cleanedIsbn)}.json";

            using var response = await client.GetAsync(url);

            if ((int)response.StatusCode == 404)
            {
                return Results.NotFound(new
                {
                    code = "RAL_OPEN_LIBRARY_BOOK_NOT_FOUND",
                    isbn = cleanedIsbn
                });
            }

            if (!response.IsSuccessStatusCode)
            {
                return Results.Problem(
                    "Open Library could not complete the lookup.",
                    statusCode: 502);
            }

            using var document = JsonDocument.Parse(
                await response.Content.ReadAsStringAsync());

            var book = document.RootElement;

            string? GetString(string propertyName)
            {
                return book.TryGetProperty(propertyName, out var value) &&
                       value.ValueKind == JsonValueKind.String
                    ? value.GetString()
                    : null;
            }

            string? GetFirstArrayString(string propertyName)
            {
                if (!book.TryGetProperty(propertyName, out var values) ||
                    values.ValueKind != JsonValueKind.Array ||
                    values.GetArrayLength() == 0)
                {
                    return null;
                }

                var first = values[0];

                return first.ValueKind == JsonValueKind.String
                    ? first.GetString()
                    : null;
            }

            string? GetFirstObjectKey(string propertyName)
            {
                if (!book.TryGetProperty(propertyName, out var values) ||
                    values.ValueKind != JsonValueKind.Array ||
                    values.GetArrayLength() == 0)
                {
                    return null;
                }

                var first = values[0];

                return first.TryGetProperty("key", out var key)
                    ? key.GetString()
                    : null;
            }

            string? coverImageUrl = null;

            if (book.TryGetProperty("covers", out var covers) &&
                covers.ValueKind == JsonValueKind.Array &&
                covers.GetArrayLength() > 0 &&
                covers[0].TryGetInt64(out var coverId))
            {
                coverImageUrl =
                    $"https://covers.openlibrary.org/b/id/{coverId}-L.jpg";
            }

            var languageKey = GetFirstObjectKey("languages");
            var languageCode = languageKey?.Split('/').LastOrDefault();

            return Results.Json(new
            {
                ISBN10 = GetFirstArrayString("isbn_10"),
                ISBN13 = GetFirstArrayString("isbn_13"),
                BookTitle = GetString("title"),
                Subtitle = GetString("subtitle"),
                Publisher = GetFirstArrayString("publishers"),
                PublishedDate = GetString("publish_date"),
                Edition = GetString("physical_format"),
                LanguageCode = languageCode,
                CoverImageUrl = coverImageUrl,
                Description = (string?)null,
                OpenLibraryEditionKey = GetString("key"),
                OpenLibraryWorkKey = GetFirstObjectKey("works")
            },
            new JsonSerializerOptions
            {
                PropertyNamingPolicy = null
            });
        }
        catch (HttpRequestException)
        {
            return Results.Problem(
                "Open Library is currently unavailable.",
                statusCode: 502);
        }
    });

// GET /authors/{authorId}/books : return books linked to one local author.
app.MapGet(
    "/api/ral/v01/authors/{authorId}/books",
    async (HttpRequest request, string authorId) =>
    {
        var scope =
            await ReadScopeAsync(request, app.Configuration);

        if (scope is null)
            return Results.Unauthorized();

        if (!scope.Has("ral.books.read"))
            return Forbidden("ral.books.read");

        if (!ValidId(authorId))
            return Results.BadRequest(new
            {
                code = "RAL_AUTHOR_ID_INVALID"
            });

        var linksJson = await ExecuteActionProcedureAsync(
        connectionString,
        scope,
        "ral.ral_BookAuthors_CRUD_JSON",
        "SELECT",
        new
        {
            AuthorID = authorId
        });

        using var links = JsonDocument.Parse(linksJson);

        var activeLinks = links.RootElement
            .EnumerateArray()
            .Where(link =>
                !link.TryGetProperty("IsActive", out var isActive) ||
                isActive.GetBoolean())
            .Select(link => link.Clone())
            .ToArray();

        return Results.Json(
            activeLinks,
            new JsonSerializerOptions
            {
                PropertyNamingPolicy = null
            });
    });

// GET /books/{bookId}/authors : return authors linked to one local book.
app.MapGet(
    "/api/ral/v01/books/{bookId}/authors",
    async (HttpRequest request, string bookId) =>
    {
        var scope =
            await ReadScopeAsync(request, app.Configuration);

        if (scope is null)
            return Results.Unauthorized();

        if (!scope.Has("ral.books.read"))
            return Forbidden("ral.books.read");

        if (!ValidId(bookId))
        {
            return Results.BadRequest(new
            {
                code = "RAL_BOOK_ID_INVALID"
            });
        }

        var linksJson = await ExecuteActionProcedureAsync(
        connectionString,
        scope,
        "ral.ral_BookAuthors_CRUD_JSON",
        "SELECT",
        new
        {
            BookID = bookId
        });

        using var links = JsonDocument.Parse(linksJson);

        var activeLinks = links.RootElement
            .EnumerateArray()
            .Where(link =>
                !link.TryGetProperty("IsActive", out var isActive) ||
                isActive.GetBoolean())
            .Select(link => link.Clone())
            .ToArray();

        return Results.Json(
            activeLinks,
            new JsonSerializerOptions
            {
                PropertyNamingPolicy = null
            });
    });

// POST /books/{bookId}/authors/{authorId} : link a local book to a local author.
app.MapPost(
    "/api/ral/v01/books/{bookId}/authors/{authorId}",
    async (
        HttpRequest request,
        string bookId,
        string authorId,
        int? authorOrder,
        string? contributionCode) =>
    {
        var scope =
            await ReadScopeAsync(request, app.Configuration);

        if (scope is null)
            return Results.Unauthorized();

        if (!scope.Has("ral.books.write"))
            return Forbidden("ral.books.write");

        if (!ValidId(bookId))
        {
            return Results.BadRequest(new
            {
                code = "RAL_BOOK_ID_INVALID"
            });
        }

        if (!ValidId(authorId))
        {
            return Results.BadRequest(new
            {
                code = "RAL_AUTHOR_ID_INVALID"
            });
        }

        if (authorOrder is < 1 or > 100)
        {
            return Results.BadRequest(new
            {
                code = "RAL_AUTHOR_ORDER_INVALID",
                minimum = 1,
                maximum = 100
            });
        }

        var resolvedAuthorOrder = authorOrder ?? 1;
        var resolvedContributionCode =
            CleanText(contributionCode) ?? "AUTHOR";

        var existingLinksJson =
            await ExecuteActionProcedureAsync(
                connectionString,
                scope,
                "ral.ral_BookAuthors_CRUD_JSON",
                "SELECT",
                new
                {
                    BookID = bookId,
                    AuthorID = authorId
                });

        using var existingLinks =
            JsonDocument.Parse(existingLinksJson);

        if (existingLinks.RootElement.ValueKind ==
                JsonValueKind.Array &&
            existingLinks.RootElement.GetArrayLength() > 0)
        {
            var existingLink = existingLinks.RootElement[0];

            var bookAuthorId =
                existingLink
                    .GetProperty("BookAuthorID")
                    .GetString();

            if (string.IsNullOrWhiteSpace(bookAuthorId))
            {
                return Results.Problem(
                    "The existing book-author link could not be identified.",
                    statusCode: 500);
            }

            var isActive =
                !existingLink.TryGetProperty(
                    "IsActive",
                    out var existingIsActive) ||
                existingIsActive.GetBoolean();

            if (isActive)
            {
                return Results.Conflict(new
                {
                    code = "RAL_BOOK_AUTHOR_ALREADY_LINKED"
                });
            }

            return Json(await ExecuteActionProcedureAsync(
                connectionString,
                scope,
                "ral.ral_BookAuthors_CRUD_JSON",
                "UPDATE",
                new
                {
                    BookAuthorID = bookAuthorId,
                    AuthorOrder = resolvedAuthorOrder,
                    ContributionCode = resolvedContributionCode,
                    IsActive = true
                }));
        }

        return Json(
            await ExecuteActionProcedureAsync(
                connectionString,
                scope,
                "ral.ral_BookAuthors_CRUD_JSON",
                "INSERT",
                new
                {
                    BookID = bookId,
                    AuthorID = authorId,
                    AuthorOrder = resolvedAuthorOrder,
                    ContributionCode = resolvedContributionCode
                }),
            201);
    });

// DELETE /books/{bookId}/authors/{authorId} : remove an author link from a book.
app.MapDelete(
    "/api/ral/v01/books/{bookId}/authors/{authorId}",
    async (
        HttpRequest request,
        string bookId,
        string authorId) =>
    {
        var scope =
            await ReadScopeAsync(request, app.Configuration);

        if (scope is null)
            return Results.Unauthorized();

        if (!scope.Has("ral.books.write"))
            return Forbidden("ral.books.write");

        if (!ValidId(bookId))
        {
            return Results.BadRequest(new
            {
                code = "RAL_BOOK_ID_INVALID"
            });
        }

        if (!ValidId(authorId))
        {
            return Results.BadRequest(new
            {
                code = "RAL_AUTHOR_ID_INVALID"
            });
        }

        var linksJson = await ExecuteActionProcedureAsync(
            connectionString,
            scope,
            "ral.ral_BookAuthors_CRUD_JSON",
            "SELECT",
            new
            {
                BookID = bookId,
                AuthorID = authorId
            });

        using var links = JsonDocument.Parse(linksJson);

        if (links.RootElement.ValueKind != JsonValueKind.Array ||
            links.RootElement.GetArrayLength() == 0)
        {
            return Results.NotFound(new
            {
                code = "RAL_BOOK_AUTHOR_LINK_NOT_FOUND"
            });
        }

        var bookAuthorId =
            links.RootElement[0]
                .GetProperty("BookAuthorID")
                .GetString();

        if (string.IsNullOrWhiteSpace(bookAuthorId))
        {
            return Results.Problem(
                "The book-author link could not be identified.",
                statusCode: 500);
        }

        return Json(await ExecuteActionProcedureAsync(
            connectionString,
            scope,
            "ral.ral_BookAuthors_CRUD_JSON",
            "DELETE",
            new
            {
                BookAuthorID = bookAuthorId
            }));
    });

// USER BOOKS ENDPOINTS
// GET current member's reading records.
app.MapGet("/api/ral/v01/user-books", async (HttpRequest request) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.user-books.read")) 
        return Forbidden("ral.user-books.read");

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_UserBooks_CRUD_JSON", "SELECT", new { MemberID = scope.MemberId }));
});

// POST add/upsert a book-read record.
app.MapPost("/api/ral/v01/user-books", async (HttpRequest request, UserBookInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.user-books.write")) 
        return Forbidden("ral.user-books.write");

    if (string.IsNullOrWhiteSpace(input.BookID)) 
        return Results.BadRequest(new { code = "RAL_BOOKID_REQUIRED" });

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_UserBooks_CRUD_JSON", "INSERT", new
    {
        BookID = input.BookID,
        ReadingStatusCode = input.ReadingStatusCode ?? "READ",
        StartedDate = input.StartedDate,
        FinishedDate = input.FinishedDate,
        Rating = input.Rating,
        ReviewText = input.ReviewText?.Trim(),
        PrivateNote = input.PrivateNote?.Trim(),
        SourceCode = input.SourceCode ?? "MANUAL"
    }), 201);
});

// PUT update an existing reading record (status, dates, rating, notes).
app.MapPut("/api/ral/v01/user-books/{userBookId}", async (HttpRequest request, string userBookId, UserBookInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.user-books.write")) 
        return Forbidden("ral.user-books.write");

    if (userBookId.Length != 32) 
        return Results.BadRequest(new { code = "RAL_INPUT_INVALID" });

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_UserBooks_CRUD_JSON", "UPDATE", new
    {
        UserBookID = userBookId,
        ReadingStatusCode = input.ReadingStatusCode,
        StartedDate = input.StartedDate,
        FinishedDate = input.FinishedDate,
        Rating = input.Rating,
        ReviewText = input.ReviewText?.Trim(),
        PrivateNote = input.PrivateNote?.Trim(),
        SourceCode = input.SourceCode
    }));
});

// DELETE soft-deactivates a reading record.
app.MapDelete("/api/ral/v01/user-books/{userBookId}", async (HttpRequest request, string userBookId) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.user-books.delete")) 
        return Forbidden("ral.user-books.delete");

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_UserBooks_CRUD_JSON", "DELETE", new { UserBookID = userBookId }));
});

// READER PROFILE ENDPOINTS
// GET
app.MapGet("/api/ral/v01/reader-profile", async (HttpRequest request) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) 
        return Results.Unauthorized();

    if (!scope.Has("ral.reader-profile.read"))
        return Forbidden("ral.reader-profile.read");

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_ReaderProfile_CRUD_JSON", "SELECT", new { }));
});

// POST
app.MapPost("/api/ral/v01/reader-profile", async (HttpRequest request, ReaderProfileInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null)
        return Results.Unauthorized();

    if (!scope.Has("ral.reader-profile.write"))
        return Forbidden("ral.reader-profile.write");

    var statusCode = string.IsNullOrWhiteSpace(input.ReaderStatusCode) ? "null" : input.ReaderStatusCode.Trim().ToUpperInvariant();

    var validStatuses =
    new[]
    {
        "ACTIVE",
        "INACTIVE",
        "PENDING",
        "SUSPENDED"
    };

    if (!validStatuses.Contains(statusCode))
    {
        return Results.BadRequest(
            new
            {
                code = "RAL_READER_STATUS_INVALID",
                message = "readerStatusCode must be ACTIVE, INACTIVE, PENDING, or SUSPENDED."
            });
    }

    var payload =
    new
    {
        ReaderDisplayName =
        input.ReaderDisplayName?.Trim(),
        PreferredGenres =
        input.PreferredGenres?.Trim(),
        PreferredAuthors =
        input.PreferredAuthors?.Trim(),
        AlertOptIn = input.AlertOptIn,
        BooksellerMembershipOptIn = input.BooksellerMembershipOptIn,
        ReaderStatusCode = statusCode
    };

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_ReaderProfile_CRUD_JSON", "INSERT", payload), 201);
});


// PUT
app.MapPut("/api/ral/v01/reader-profile", async (HttpRequest request, ReaderProfileInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null)
            return Results.Unauthorized();

    if (!scope.Has("ral.reader-profile.write"))
        return Forbidden("ral.reader-profile.write");

    var statusCode = string.IsNullOrWhiteSpace(input.ReaderStatusCode)?"ACTIVE" : input.ReaderStatusCode.Trim().ToUpperInvariant();

    var validStatuses =
    new[]
    {
        "ACTIVE",
        "INACTIVE",
        "PENDING",
        "SUSPENDED"
    };

    if (statusCode is not null && !validStatuses.Contains(statusCode))
    {
        return Results.BadRequest(
            new
            {
                code = "RAL_READER_STATUS_INVALID",
                message = "readerStatusCode must be ACTIVE, INACTIVE, PENDING, or SUSPENDED."
            });
    }

var payload = 
    new 
    {
        ReaderDisplayName = input.ReaderDisplayName?.Trim(),
        PreferredGenres = input.PreferredGenres?.Trim(),
        PreferredAuthors = input.PreferredAuthors?.Trim(),
        AlertOptIn = input.AlertOptIn,
        BooksellerMembershipOptIn = input.BooksellerMembershipOptIn,
        ReaderStatusCode = statusCode
    };

    return Json(await ExecuteCrudAsync(connectionString, scope, "ral.ral_ReaderProfile_CRUD_JSON", "UPDATE", payload));
});

// BOOK SCAN ENDPOINTS
app.MapPost("/api/ral/v01/books/search", async (HttpRequest request, BookSearchInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);

    if (scope is null) return Results.Unauthorized();

    if (!scope.Has("ral.books.read")) 
        return Forbidden("ral.books.read");

    if (string.IsNullOrWhiteSpace(input.SearchText))
        return Results.BadRequest(new { code = "RAL_SEARCH_TEXT_REQUIRED" });

    return Json(await ExecutePayloadProcAsync(connectionString, scope, "ral.ral_SearchBooks_JSON", new
    {
        SearchType = input.SearchType ?? "TITLE_SEARCH",
        SearchText = input.SearchText.Trim(),
        Limit = input.Limit ?? 25,
        ExternalSourceCode = input.ExternalSourceCode?.Trim()
    }));
});

app.MapPost("/api/ral/v01/books/scan", async (HttpRequest request, BookScanInput input) =>
{
    var scope = await ReadScopeAsync(request, app.Configuration);
    if (scope is null) return Results.Unauthorized();
    if (!scope.Has("ral.books.read")) return Forbidden("ral.books.read");
    if (string.IsNullOrWhiteSpace(input.ISBN13))
        return Results.BadRequest(new { code = "RAL_ISBN_REQUIRED" });
    return Json(await ExecutePayloadProcAsync(connectionString, scope, "ral.ral_ScanBook_JSON", new
    {
        ISBN13 = input.ISBN13.Trim(),
        ExternalSourceCode = input.ExternalSourceCode?.Trim()
    }));
});


// Student-only harness. It cannot run in a deployed environment: Development plus
// RalStandalone:Enabled are both mandatory. It demonstrates host-context delivery;
// it is not an authentication or authorization bypass.
app.MapPost("/standalone/context", () =>
{
    if (!standalone) return Results.NotFound();

    var key = app.Configuration["RalSecurity:SigningKeyBase64"];

    if (string.IsNullOrWhiteSpace(key))
        return Results.Problem("Signing key is unavailable", statusCode: 503);

    var now = DateTime.UtcNow;

    var claims = new List<Claim>
    {
        new("tenant_id", "F115B0A094467E7FCBA8DB16DF52242E"),
        new("member_id", "00000000000000000000000000000001"),

        new("permissions", "ral.authors.read"),
        new("permissions", "ral.authors.write"),
        new("permissions", "ral.authors.delete"),

        new("permissions", "ral.books.read"),
        new("permissions", "ral.books.write"),
        new("permissions", "ral.books.delete"),

        new("permissions", "ral.user-books.read"),
        new("permissions", "ral.user-books.write"),
        new("permissions", "ral.user-books.delete"),

        new("permissions", "ral.reader-profile.read"),
        new("permissions", "ral.reader-profile.write")
    };

    var token = new JwtSecurityToken(
        app.Configuration["RalSecurity:Issuer"] ?? "ral-standalone",
        app.Configuration["RalSecurity:Audience"] ?? "ral-widget",
        claims,
        now,
        now.AddHours(2),
        new SigningCredentials(
            new SymmetricSecurityKey(Convert.FromBase64String(key)),
            SecurityAlgorithms.HmacSha256));
    return Results.Ok(new
    {
        token = new JwtSecurityTokenHandler().WriteToken(token)
    });
});

app.MapGet("/standalone", (IWebHostEnvironment env) => standalone ? Results.File(Path.Combine(env.WebRootPath, "standalone.html"), "text/html") : Results.NotFound());
app.Run();

static async Task<RalScope?> ReadScopeAsync(HttpRequest request, IConfiguration configuration)
{
    try
    {
        var header = request.Headers.Authorization.ToString();
        if (!header.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase)) return null;
        var key = configuration["RalSecurity:SigningKeyBase64"]; if (string.IsNullOrWhiteSpace(key)) return null;
        var result = await new JsonWebTokenHandler().ValidateTokenAsync(header[7..], new TokenValidationParameters { ValidateIssuer = true, ValidIssuer = configuration["RalSecurity:Issuer"], ValidateAudience = true, ValidAudience = configuration["RalSecurity:Audience"], ValidateLifetime = true, ValidateIssuerSigningKey = true, IssuerSigningKey = new SymmetricSecurityKey(Convert.FromBase64String(key)), ClockSkew = TimeSpan.FromSeconds(30) });
        if (!result.IsValid || result.ClaimsIdentity is null) return null;
        string? Claim(string name) => result.ClaimsIdentity.Claims.FirstOrDefault(c => c.Type == name)?.Value;
        var tenantId = Claim("tenant_id"); var memberId = Claim("member_id"); if (tenantId?.Length != 32 || memberId?.Length != 32) return null;
        return new RalScope(tenantId, memberId, result.ClaimsIdentity.Claims.Where(c => c.Type == "permissions").Select(c => c.Value).ToHashSet(StringComparer.OrdinalIgnoreCase));
    }
    catch { return null; }
}

static async Task<string> ExecuteCrudAsync(string connectionString, RalScope scope, string procedureName, string action, object payload)
{
    await using var db = new SqlConnection(connectionString);
    await db.OpenAsync();

    // Tenant/member values originate in the signed context, never the browser body.
    foreach (var pair in new[] { ("TenantID", scope.TenantId), ("MemberID", scope.MemberId) })
    {
        await using var command = new SqlCommand("EXEC sys.sp_set_session_context @key,@value", db);
        command.Parameters.AddWithValue("@key", pair.Item1);
        command.Parameters.AddWithValue("@value", pair.Item2);
        await command.ExecuteNonQueryAsync();
    }

    await using var crud = new SqlCommand(procedureName, db)
    {
        CommandType = CommandType.StoredProcedure
    };

    crud.Parameters.AddWithValue("@Action", action);
    crud.Parameters.Add("@Payload", SqlDbType.NVarChar, -1).Value = JsonSerializer.Serialize(payload);

    var result = new SqlParameter("@Result", SqlDbType.NVarChar, -1)
    {
        Direction = ParameterDirection.Output
    };

    crud.Parameters.Add(result);

    await crud.ExecuteNonQueryAsync();

    return result.Value is string json && !string.IsNullOrWhiteSpace(json) ? json : (action == "SELECT" ? "[]" : "{}");
}

static async Task<string> ExecuteActionProcedureAsync(
    string connectionString,
    RalScope scope,
    string procedureName,
    string action,
    object payload)
{
    await using var db = new SqlConnection(connectionString);
    await db.OpenAsync();

    // Tenant/member values originate in the signed context, never the browser body.
    foreach (var pair in new[] { ("TenantID", scope.TenantId), ("MemberID", scope.MemberId) })
    {
        await using var contextCommand = new SqlCommand(
            "EXEC sys.sp_set_session_context @key,@value",
            db);

        contextCommand.Parameters.AddWithValue("@key", pair.Item1);
        contextCommand.Parameters.AddWithValue("@value", pair.Item2);

        await contextCommand.ExecuteNonQueryAsync();
    }

    await using var command = new SqlCommand(procedureName, db)
    {
        CommandType = CommandType.StoredProcedure
    };

    command.Parameters.AddWithValue("@Action", action);

    command.Parameters
        .Add("@Payload", SqlDbType.NVarChar, -1)
        .Value = JsonSerializer.Serialize(payload);

    var output = command.Parameters.Add(
        "@Result",
        SqlDbType.NVarChar,
        -1);

    output.Direction = ParameterDirection.Output;

    var selected = await command.ExecuteScalarAsync();

    return selected?.ToString()
        ?? output.Value?.ToString()
        ?? "{}";
}

static async Task<string> ExecutePayloadProcedureAsync(
    string connectionString,
    RalScope scope,
    string procedureName,
    object payload)
{
    await using var db = new SqlConnection(connectionString);
    await db.OpenAsync();

    // Tenant/member values originate in the signed context, never the browser body.
    foreach (var pair in new[] { ("TenantID", scope.TenantId), ("MemberID", scope.MemberId) })
    {
        await using var contextCommand = new SqlCommand(
            "EXEC sys.sp_set_session_context @key,@value",
            db);

        contextCommand.Parameters.AddWithValue("@key", pair.Item1);
        contextCommand.Parameters.AddWithValue("@value", pair.Item2);

        await contextCommand.ExecuteNonQueryAsync();
    }

    await using var command = new SqlCommand(procedureName, db)
    {
        CommandType = CommandType.StoredProcedure
    };

    command.Parameters
        .Add("@Payload", SqlDbType.NVarChar, -1)
        .Value = JsonSerializer.Serialize(payload);

    var output = command.Parameters.Add(
        "@Result",
        SqlDbType.NVarChar,
        -1);

    output.Direction = ParameterDirection.Output;

    var selected = await command.ExecuteScalarAsync();

    return selected?.ToString()
        ?? output.Value?.ToString()
        ?? "{}";
}

static async Task<bool> DuplicateIsbnExistsAsync(
    string connectionString,
    RalScope scope,
    string? isbn10,
    string? isbn13,
    string? excludedBookId = null)
{
    var suppliedIsbns = new[] { isbn10, isbn13 }
        .Where(isbn => !string.IsNullOrWhiteSpace(isbn))
        .Distinct(StringComparer.OrdinalIgnoreCase);

    foreach (var isbn in suppliedIsbns)
    {
        var result = await ExecuteCrudAsync(
            connectionString,
            scope,
            "ral.ral_Books_CRUD_JSON",
            "SELECT",
            new
            {
                SearchText = isbn
            });

        if (string.IsNullOrWhiteSpace(result))
            continue;

        using var document = JsonDocument.Parse(result);

        if (document.RootElement.ValueKind != JsonValueKind.Array)
            continue;

        foreach (var book in document.RootElement.EnumerateArray())
        {
            var existingBookId =
                book.TryGetProperty("BookID", out var bookIdProperty)
                    ? bookIdProperty.GetString()
                    : null;

            if (string.Equals(
                existingBookId,
                excludedBookId,
                StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            var isActive =
                !book.TryGetProperty("IsActive", out var isActiveProperty) ||
                isActiveProperty.GetBoolean();

            if (!isActive)
                continue;

            var existingIsbn10 =
                book.TryGetProperty("ISBN10", out var isbn10Property)
                    ? isbn10Property.GetString()
                    : null;

            var existingIsbn13 =
                book.TryGetProperty("ISBN13", out var isbn13Property)
                    ? isbn13Property.GetString()
                    : null;

            if (string.Equals(
                    existingIsbn10,
                    isbn,
                    StringComparison.OrdinalIgnoreCase) ||
                string.Equals(
                    existingIsbn13,
                    isbn,
                    StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }
    }

    return false;
}

static async Task<string> ExecutePayloadProcAsync(
    string connectionString, RalScope scope,
    string procedureName, object payload)
{
    await using var db = new SqlConnection(connectionString);
    await db.OpenAsync();

    foreach (var (key, value) in new[] { ("TenantID", scope.TenantId), ("MemberID", scope.MemberId) })
    {
        await using var ctx = new SqlCommand("EXEC sys.sp_set_session_context @key, @value", db);
        ctx.Parameters.AddWithValue("@key", key);
        ctx.Parameters.AddWithValue("@value", value);
        await ctx.ExecuteNonQueryAsync();
    }

    await using var cmd = new SqlCommand(procedureName, db) { CommandType = CommandType.StoredProcedure };
    cmd.Parameters.Add("@Payload", SqlDbType.NVarChar, -1).Value = JsonSerializer.Serialize(payload);
    var result = cmd.Parameters.Add("@Result", SqlDbType.NVarChar, -1);
    result.Direction = ParameterDirection.Output;
    await cmd.ExecuteNonQueryAsync();
    return result.Value as string ?? "{}";
}

static IResult Forbidden(string permission) => Results.Json(new { code = "RAL_PERMISSION_REQUIRED", requiredPermission = permission }, statusCode: 403);
static IResult Json(string body, int statusCode = 200) => Results.Text(body, "application/json", Encoding.UTF8, statusCode);
static BookRequest CleanBook(BookRequest input) => new(
    NormaliseIsbn(input.ISBN10),
    NormaliseIsbn(input.ISBN13),
    input.BookTitle,
    CleanText(input.Subtitle),
    CleanText(input.Publisher),
    CleanText(input.PublishedDate),
    CleanText(input.Edition),
    CleanText(input.LanguageCode),
    CleanText(input.CoverImageUrl),
    CleanText(input.Description));

static string? CleanText(string? value) =>
    string.IsNullOrWhiteSpace(value) ? null : value.Trim();

static string? NormaliseIsbn(string? value)
{
    if (string.IsNullOrWhiteSpace(value))
        return null;

    return new string(
        value
            .Where(character =>
                !char.IsWhiteSpace(character) &&
                character != '-')
            .Select(char.ToUpperInvariant)
            .ToArray());
}

static bool ValidIsbn10(string? value) =>
    value is null || (value.Length == 10 && value[..9].All(char.IsDigit) &&(char.IsDigit(value[9]) || value[9] == 'X'));

static bool ValidIsbn13(string? value) =>
    value is null || (value.Length == 13 && value.All(char.IsDigit));

static bool ValidId(string? value) => value?.Length == 32;
record RalScope(string TenantId, string MemberId, HashSet<string> Permissions) { public bool Has(string permission) => Permissions.Contains(permission); }

// AUTHOR RECORDS
record AuthorCreateInput(
    string AuthorName,
    string? AuthorSortName,
    string? Biography,
    string? Country,
    string? WebsiteUrl,
    bool? IsVerified,
    string? AuthorComments);
record AuthorUpdateInput(
    string? AuthorName,
    string? AuthorSortName,
    string? Biography,
    string? Country,
    string? WebsiteUrl,
    bool? IsVerified,
    string? AuthorComments,
    bool? IsActive);

// BOOK RECORDS
record BookRequest(
    string? ISBN10,
    string? ISBN13,
    string? BookTitle,
    string? Subtitle,
    string? Publisher,
    string? PublishedDate,
    string? Edition,
    string? LanguageCode,
    string? CoverImageUrl,
    string? Description);

// USER BOOK RECORD
record UserBookInput(
    string? BookID,
    string? ReadingStatusCode,
    string? StartedDate,
    string? FinishedDate,
    int? Rating,
    string? ReviewText,
    string? PrivateNote,
    string? SourceCode);

// READER PROFILE RECORD
record ReaderProfileInput(
    string? ReaderDisplayName,
    string? PreferredGenres,
    string? PreferredAuthors,
    bool AlertOptIn,
    bool BooksellerMembershipOptIn,
    string? ReaderStatusCode);

// BOOK SCAN/LOOKUP RECORDS
record BookSearchInput(
    string? SearchText,
    string? SearchType,
    int? Limit,
    string? ExternalSourceCode);
record BookScanInput(
    string? ISBN,
    string? ISBN10,
    string? ISBN13,
    string? ExternalSourceCode);