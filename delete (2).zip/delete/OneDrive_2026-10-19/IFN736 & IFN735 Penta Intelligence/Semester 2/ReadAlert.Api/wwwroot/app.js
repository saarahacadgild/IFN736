﻿let currentToken = null;

// Request auth token from the backend 
document.querySelector('#getTokenButton').addEventListener('click', async () => {
    const response = await fetch('/standalone/context', { method: 'POST' });
    const data = await response.json();
    currentToken = data.token;
});

// Search button which reads typed Author name and retrieves matching ones
document.querySelector('#searchButton').addEventListener('click', () => {
    fetchAuthors(document.querySelector('#authorSearch').value);
});

// Retrieve Author information from local database and Open Library API
async function fetchAuthors(searchText) {
    if (!searchText) return;

    const headers = {
        'Authorization': `Bearer ${currentToken}`
    };

    // Search local database
    const dbSearch = await fetch(
        `/api/ral/v01/authors?searchText=${encodeURIComponent(searchText)}`,
        {
            headers: headers
        }
    );

    // Search Open Library Author API
    const openLibrarySearch = await fetch(
        `/api/ral/v01/authors/search?name=${encodeURIComponent(searchText)}`,
        {
            headers: headers
        }
    );

    const dbData = await dbSearch.json();
    const openLibraryData = await openLibrarySearch.json();

    console.log('DB data:', dbData);
    console.log('Open Library data:', openLibraryData);

    authorResults.innerHTML = "";
    document.querySelector(".scrollable-table").style.display = "block";

    // Display authors from local database
    if (Array.isArray(dbData)) {
        dbData.forEach(author => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td class="author-name" data-author-id="${author.AuthorID}">
                    ${author.AuthorName ?? ""}
                </td>
                <td>${author.Biography ?? ""}</td>
                <td>${author.Country ?? ""}</td>
                <td>${author.WebsiteUrl ?? ""}</td>
                <td>
                    <button class="edit-author-button" data-author-id="${author.AuthorID}">
                        Edit
                    </button>
                </td>
            `;

            authorResults.appendChild(row);
        });
    }

    // Display authors from Open Library API
    openLibraryData.docs.forEach(author => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td class="author-name">${author.name ?? ""}</td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        `;

        authorResults.appendChild(row);
    });
}

// Check whether an Author exists in local database
async function doesAuthorExist(authorName) {
    const response = await fetch(
        `/api/ral/v01/authors?searchText=${encodeURIComponent(authorName)}`,
        {
            headers: {
                'Authorization': `Bearer ${currentToken}`
            }
        }
    );

    const authors = await response.json();

    if (!Array.isArray(authors)) {
        return null;
    }

    return authors.find(author => author.AuthorName === authorName) ?? null;
}

// Save Author to local database
async function saveAuthor(authorName) {

    const response = await fetch('/api/ral/v01/authors', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${currentToken}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            AuthorName: authorName
        })
    });

    if (!response.ok) {
        throw new Error('Failed to save author');
    }

    return await response.json();
}

// Update Author information in local database
async function updateAuthor(authorId, authorName, biography, country, websiteUrl) {
    const response = await fetch(
        `/api/ral/v01/authors/${authorId}`,
        {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${currentToken}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                AuthorName: authorName,
                Biography: biography,
                Country: country,
                WebsiteUrl: websiteUrl
            })
        }
    );

    if (!response.ok) {
        throw new Error('Failed to update author');
    }

    return await response.json();
}

// 'Success' message alert
function showSuccessMessage(message) {
    const successMessage = document.querySelector('#successMessage');
    const successText = document.querySelector('#successText');

    successText.textContent = message;

    successMessage.classList.add('show');

    setTimeout(() => {
        successMessage.classList.remove('show');
    }, 3000);
}

// Authors table click, edit and save button
authorResults.addEventListener('click', async (event) => {

    // Clicking Author name saves Author to database (applicable to API results)
    if (event.target.classList.contains('author-name')) {

        const authorName = event.target.textContent.trim();

        let authorId = event.target.dataset.authorId;

        if (authorId) {

            console.log('Local author selected:', authorName);

        } else {

            console.log('Open Library author selected:', authorName);

            const author = await doesAuthorExist(authorName);

            if (author) {
                // Use existing ID
                authorId = author.AuthorID;

            } else {
                // Save 
                const newAuthor = await saveAuthor(authorName);

                authorId = newAuthor.AuthorID;

                showSuccessMessage(
                    `${authorName} has been added to the database.`
                );
            }

            event.target.dataset.authorId = authorId;

            // Add 'Edit' button after the Open Library author
            // has been saved to the database
            const row = event.target.closest('tr');
            const editCell = row.lastElementChild;

            editCell.innerHTML = `
                <button class="edit-author-button" data-author-id="${authorId}">
                    Edit
                </button>
            `;
        }

        console.log('Selected AuthorID:', authorId);
    }


    // Edit Button for editing of Author details
    if (event.target.classList.contains('edit-author-button')) {

        const button = event.target;
        const authorId = button.dataset.authorId;
        const row = button.closest('tr');

        const authorNameCell = row.querySelector('.author-name');

        const currentName = authorNameCell.textContent.trim();
        const currentBiography = row.children[1].textContent.trim();
        const currentCountry = row.children[2].textContent.trim();
        const currentWebsite = row.children[3].textContent.trim();

        row.children[0].innerHTML = `
            <input type="text" value="${currentName}" class="edit-name">
        `;

        row.children[1].innerHTML = `
            <textarea class="edit-biography">${currentBiography}</textarea>
        `;

        row.children[2].innerHTML = `
            <input type="text" value="${currentCountry}" class="edit-country">
        `;

        row.children[3].innerHTML = `
            <input type="text" value="${currentWebsite}" class="edit-website">
        `;

        row.lastElementChild.innerHTML = `
            <button class="save-author-button" data-author-id="${authorId}">
                Save
            </button>
        `;
    }


    // Save Button for saving edited Author details
    if (event.target.classList.contains('save-author-button')) {

        const button = event.target;
        const authorId = button.dataset.authorId;
        const row = button.closest('tr');

        const authorName = row.querySelector('.edit-name').value;
        const biography = row.querySelector('.edit-biography').value;
        const country = row.querySelector('.edit-country').value;
        const websiteUrl = row.querySelector('.edit-website').value;

        try {

            await updateAuthor(
                authorId,
                authorName,
                biography,
                country,
                websiteUrl
            );

            row.children[0].innerHTML = `
                <span class="author-name" data-author-id="${authorId}">
                    ${authorName}
                </span>
            `;

            row.children[1].textContent = biography;
            row.children[2].textContent = country;
            row.children[3].textContent = websiteUrl;

            row.lastElementChild.innerHTML = `
                <button class="edit-author-button" data-author-id="${authorId}">
                    Edit
                </button>
            `;

            showSuccessMessage(
                `${authorName} has been updated.`
            );

            console.log('Author updated:', authorId);

        } catch (error) {

            console.error('Error updating author:', error);

        }
    }
});