﻿# ReadAlert Author Catalogue
This is the Author Catalogue module developed for ReadAlert. It allows administrators to search for Authors using a local DB and third-party API (Open Library).

## Features

Users can do the following:
* Search for Authors using local DB and Open Library.
* View results from both sources.
* View additional information of Authors (Biography, Country, and Website).
* Select an Author, and if they do not exist in the local DB, add them automatically.
* Each local Author is associated with an Author ID.
* Author information can be edited and saved once added to the local DB.

## API Endpoints
* GET /api/ral/v01/health — Checks whether the RAL service is running.
* GET /api/ral/v01/readiness — Checks whether the service is ready and the required author stored procedure is available.

### Authors
* GET /api/ral/v01/authors — Retrieves authors from the local database. Supports the optional searchText parameter.
* POST /api/ral/v01/authors — Adds a new author to the local database.
* PUT /api/ral/v01/authors/{authorId} — Updates an existing author.
* DELETE /api/ral/v01/authors/{authorId} — Deactivates an existing author.

### External Author Search
* GET /api/ral/v01/authors/search — Searches the Open Library Author API using the provided author name.

### Development
* POST /standalone/context — Generates a temporary development authentication token for the standalone application.
* GET /standalone — Opens the standalone ReadAlert application in the development environment.

## How to Run
### Database Setup
* Open SQL Server Management Studio (SSMS).
* Connect to the local SQL Server instance.
* Ensure the Cobbled_NoRLS database is available.
* Run the required seed scripts to provide the TenantID and MemberID values.
* Run the ReadAlert SQL scripts against Cobbled_NoRLS to create the required tables and stored procedures.

### Running the Module
* Open the `ReadAlert.Api` folder in Visual Studio.
* Open a terminal and navigate into the inner `ReadAlert.Api` folder:
  `cd ReadAlert.Api`
* Ensure the `CobbledData` connection string in `appsettings.json` points to the `Cobbled_NoRLS` database.
* Run the ASP.NET application with `dotnet run`.
